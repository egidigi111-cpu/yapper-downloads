"""
NUKE-TERMINAL (Corona-like) - Desktop Version
Ablauf:
  [1] Token eingeben -> wird gecheckt -> weiter zu Nuke-Menue
  Nuke-Menue:
  [1] Jeden Kicken / [2] Jeden Bannen / [3] Alle Kanaele loeschen (ausser 1)
  [4] Rollen loeschen / [5] FULL NUKE

NUR EIGENER SERVER / MIT ERLAUBNIS! Sonst Discord-ToS-Verstoss.
Bot braucht Administrator + SERVER MEMBERS INTENT im Developer Portal.
"""

import asyncio
import os
import sys
import time

import aiohttp

try:
    import discord
except ImportError:
    print("=" * 60)
    print(" discord.py fehlt! Installiere:")
    print(" pip install -r requirements.txt")
    print("=" * 60)
    input("\nEnter zum Beenden...")
    sys.exit(1)

try:
    from colorama import init as colorama_init, Fore, Style
    colorama_init()
    GREEN, RED, YELLOW, CYAN = Fore.GREEN, Fore.RED, Fore.YELLOW, Fore.CYAN
    RESET = Style.RESET_ALL
except ImportError:
    GREEN = RED = YELLOW = CYAN = RESET = ""

BASE = os.path.dirname(os.path.abspath(__file__))
TOKEN_FILE = os.path.join(BASE, "token.txt")


def cprint(t, c=""):
    print(f"{c}{t}{RESET}")


def banner():
    os.system("cls" if os.name == "nt" else "clear")
    try:
        os.system("title Nuke-Terminal")
    except Exception:
        pass
    print(r"""
  _   _ _   _ _  __ _____
 | \ | | | | | |/ /| ____|
 |  \| | | | | ' / |  _|
 | |\  | |_| | . \ | |___
 |_| \_|\___/|_|\_\|_____|
     NUKE - TERMINAL
""")


async def ainput(prompt=""):
    return await asyncio.to_thread(input, prompt)


class NukeBot(discord.Client):
    def __init__(self):
        # Schlank = schneller READY: keine Presence, kein Chunk beim Start
        intents = discord.Intents.none()
        intents.guilds = True
        intents.members = True  # braucht SERVER MEMBERS INTENT im Portal
        intents.messages = True
        super().__init__(intents=intents, chunk_guilds_at_startup=False,
                         max_messages=None)
        self.ready_event = asyncio.Event()

    async def on_ready(self):
        self.ready_event.set()


def load_saved_token():
    if os.path.exists(TOKEN_FILE):
        try:
            with open(TOKEN_FILE, "r", encoding="utf-8") as f:
                t = f.read().strip()
                if len(t) > 20:
                    return t
        except OSError:
            pass
    return None


# ---------- Aktionen ----------

async def ban_all(guild, bot, also_bots=False):
    targets = [m for m in guild.members
               if m.id not in (bot.user.id, guild.owner_id)
               and m != guild.me and (also_bots or not m.bot)]
    cprint(f"\nBanne {len(targets)} Mitglieder...", YELLOW)
    ok = fail = 0
    sem = asyncio.Semaphore(8)

    async def do(m):
        nonlocal ok, fail
        async with sem:
            try:
                await guild.ban(m, reason="nuke", delete_message_days=0)
                ok += 1
                print(f"  [BAN] {m}")
            except Exception as e:
                fail += 1
                print(f"  [FAIL] {m}: {type(e).__name__}")
            await asyncio.sleep(0.25)

    await asyncio.gather(*(do(m) for m in targets))
    cprint(f"Fertig: {ok} gebannt, {fail} Fehler.", GREEN)


async def kick_all(guild, bot, also_bots=False):
    targets = [m for m in guild.members
               if m.id not in (bot.user.id, guild.owner_id)
               and m != guild.me and (also_bots or not m.bot)]
    cprint(f"\nKicke {len(targets)} Mitglieder...", YELLOW)
    ok = fail = 0
    sem = asyncio.Semaphore(8)

    async def do(m):
        nonlocal ok, fail
        async with sem:
            try:
                await m.kick(reason="nuke")
                ok += 1
                print(f"  [KICK] {m}")
            except Exception as e:
                fail += 1
                print(f"  [FAIL] {m}: {type(e).__name__}")
            await asyncio.sleep(0.25)

    await asyncio.gather(*(do(m) for m in targets))
    cprint(f"Fertig: {ok} gekickt, {fail} Fehler.", GREEN)


async def del_channels(guild, keep_one=True):
    keep = None
    if keep_one:
        try:
            keep = await guild.create_text_channel("nuked")
            cprint(f"Keep-Kanal erstellt: #{keep.name}", CYAN)
        except Exception:
            keep = guild.text_channels[0] if guild.text_channels else None
            if keep:
                cprint(f"Behalte: #{keep.name}", CYAN)
    doomed = [c for c in list(guild.channels) if keep is None or c.id != keep.id]
    cprint(f"\nLoesche {len(doomed)} Kanaele (1 bleibt)...", YELLOW)
    ok = fail = 0
    for c in doomed:
        try:
            await c.delete(reason="nuke")
            ok += 1
            print(f"  [DEL] #{c.name}")
            await asyncio.sleep(0.2)
        except Exception as e:
            fail += 1
            print(f"  [FAIL] #{c.name}: {type(e).__name__}")
    if keep_one and keep is None:
        try:
            keep = await guild.create_text_channel("nuked")
        except Exception:
            pass
    cprint(f"Fertig: {ok} geloescht, {fail} Fehler.", GREEN)
    return keep


async def del_roles(guild):
    top = guild.me.top_role
    targets = [r for r in guild.roles
               if not r.is_default() and not r.managed and r < top
               and not (r.tags and (r.tags.bot_id or r.tags.integration_id))]
    cprint(f"\nLoesche {len(targets)} Rollen...", YELLOW)
    ok = fail = 0
    for r in targets:
        try:
            await r.delete(reason="nuke")
            ok += 1
            print(f"  [DEL-ROLLE] {r.name}")
            await asyncio.sleep(0.2)
        except Exception as e:
            fail += 1
            print(f"  [FAIL] {r.name}: {type(e).__name__}")
    cprint(f"Fertig: {ok} geloescht, {fail} Fehler.", GREEN)


async def full_nuke(guild, bot):
    cprint(f"\n!!! FULL NUKE auf '{guild.name}' !!!", RED)
    await del_roles(guild)
    keep = await del_channels(guild, True)
    w = (await ainput("Auch Bots bannen? (j/n): ")).strip().lower()
    await ban_all(guild, bot, also_bots=w in ("j", "ja", "y"))
    if keep:
        try:
            await keep.send("Server genuked. 1 Kanal bleibt.")
        except Exception:
            pass
    cprint("FULL NUKE fertig.", GREEN)


# ---------- Menues ----------

async def pick_guild(bot):
    guilds = list(bot.guilds)
    if not guilds:
        cprint("\nBot ist auf KEINEM Server!", RED)
        cprint(f"Lade ihn ein:\nhttps://discord.com/oauth2/authorize?client_id={bot.user.id}&permissions=8&scope=bot", YELLOW)
        await ainput("\nEnter zum Zurueck...")
        return None
    print("\n--- Server waehlen ---")
    for i, g in enumerate(guilds, 1):
        print(f" [{i}] {g.name} (Member: {g.member_count})")
    print(" [0] Zurueck")
    while True:
        w = (await ainput("\nNummer: ")).strip()
        if w == "0":
            return None
        try:
            g = guilds[int(w) - 1]
            return g
        except (ValueError, IndexError):
            cprint("Ungueltig.", RED)


async def confirm(action, guild):
    w = (await ainput(f"WIRKLICH '{action}' auf '{guild.name}'? (ja/NEIN): ")).strip().lower()
    return w in ("ja", "y", "j", "yes")


async def ensure_members(guild):
    """Member-Cache schnell fuellen, aber nie haengen."""
    try:
        total = guild.member_count or 0
        if len(guild.members) >= max(total - 2, 0) or total < 10:
            return
        cprint(f"Lade {total} Member (max 8s)...", YELLOW)
        await asyncio.wait_for(guild.chunk(), timeout=8)
        cprint(f"Member geladen: {len(guild.members)}/{total}", GREEN)
    except asyncio.TimeoutError:
        cprint(f"Weiter mit Cache ({len(guild.members)} Member) - Rest wird uebersprungen.", YELLOW)
    except Exception as e:
        cprint(f"Member-Load Hinweis: {type(e).__name__} - weiter mit Cache.", YELLOW)


async def nuke_menu(bot, guild):
    try:
        guild = await bot.fetch_guild(guild.id)
        await ensure_members(guild)
    except Exception:
        pass
    while True:
        banner()
        cprint(f"Bot: {bot.user}  |  Server: {guild.name} (Member: {getattr(guild, 'member_count', '?')})", GREEN)
        cprint("Bot, Owner + hoehere Rollen werden uebersprungen.", CYAN)
        print("\n [1] Jeden Kicken")
        print(" [2] Jeden Bannen")
        print(" [3] Alle Kanaele loeschen (ausser 1)")
        print(" [4] Alle Rollen loeschen")
        print(" [5] FULL NUKE (wie Corona)")
        print(" [6] Server wechseln")
        print(" [0] Beenden")
        w = (await ainput("\nWahl: ")).strip()
        if w == "0":
            await bot.close()
            return "exit"
        if w == "6":
            return "switch"
        if w == "1":
            b = (await ainput("Auch Bots kicken? (j/n): ")).strip().lower() in ("j", "ja", "y")
            if await confirm("ALLE KICKEN", guild):
                await kick_all(guild, bot, b)
            await ainput("\nEnter...")
        elif w == "2":
            b = (await ainput("Auch Bots bannen? (j/n): ")).strip().lower() in ("j", "ja", "y")
            if await confirm("ALLE BANNEN", guild):
                await ban_all(guild, bot, b)
            await ainput("\nEnter...")
        elif w == "3":
            if await confirm("ALLE KANAELE LOESCHEN (ausser 1)", guild):
                await del_channels(guild, True)
            await ainput("\nEnter...")
        elif w == "4":
            if await confirm("ALLE ROLLEN LOESCHEN", guild):
                await del_roles(guild)
            await ainput("\nEnter...")
        elif w == "5":
            if await confirm("FULL NUKE", guild):
                await full_nuke(guild, bot)
            await ainput("\nEnter...")
        else:
            cprint("Ungueltig.", RED)
            await asyncio.sleep(1)


async def check_and_login(token):
    """Token checken: erst schneller REST-Check (~1s), dann Gateway-Login."""
    cprint("\n[CHECK] Token wird geprueft...", YELLOW)
    t0 = time.monotonic()
    # Phase 1: schneller HTTP-Check, kein 30s Gateway-Wait bei falschem Token
    try:
        timeout = aiohttp.ClientTimeout(total=8)
        async with aiohttp.ClientSession(timeout=timeout) as s:
            async with s.get("https://discord.com/api/v10/users/@me",
                             headers={"Authorization": f"Bot {token}"}) as r:
                if r.status == 401:
                    cprint(f"\n[FAIL] Token ungueltig! ({time.monotonic()-t0:.1f}s)", RED)
                    return None, None
                if r.status == 429:
                    cprint("\n[FAIL] Rate-Limit, warte kurz und retry...", RED)
                    return None, None
                if r.status != 200:
                    cprint(f"\n[FAIL] Discord meldet Fehler {r.status} ({time.monotonic()-t0:.1f}s)", RED)
                    return None, None
                data = await r.json()
                cprint(f"[REST-OK] Bot gefunden: {data.get('username')} ({time.monotonic()-t0:.1f}s) - verbinde Gateway...", GREEN)
    except asyncio.TimeoutError:
        cprint("\n[FAIL] Keine Verbindung zu Discord (Timeout).", RED)
        return None, None
    except Exception as e:
        cprint(f"\n[WARN] REST-Check fehlgeschlagen ({type(e).__name__}), versuche Gateway...", YELLOW)

    # Phase 2: Gateway-Login mit 3 Versuchen a max 8s (statt 1x 12s)
    for versuch in (1, 2, 3):
        bot = NukeBot()
        task = asyncio.create_task(bot.start(token))
        try:
            cprint(f"[Gateway] Versuch {versuch}/3...", YELLOW)
            await asyncio.wait_for(bot.ready_event.wait(), timeout=8)
            cprint(f"\n[OK] Token gueltig! Eingeloggt als: {bot.user} ({time.monotonic()-t0:.1f}s)", GREEN)
            cprint(f"Invite (Admin): https://discord.com/oauth2/authorize?client_id={bot.user.id}&permissions=8&scope=bot", CYAN)
            return bot, task
        except asyncio.TimeoutError:
            cprint(f"[Gateway] Versuch {versuch} Timeout - retry...", YELLOW)
            try:
                await bot.close()
            except Exception:
                pass
            try:
                task.cancel()
            except Exception:
                pass
            await asyncio.sleep(1)
            continue
        except discord.LoginFailure:
            cprint("\n[FAIL] Token ungueltig (LoginFailure)!", RED)
            try:
                await bot.close()
            except Exception:
                pass
            return None, None
        except Exception as e:
            cprint(f"[Gateway] Fehler {type(e).__name__} - retry...", YELLOW)
            try:
                await bot.close()
            except Exception:
                pass
            try:
                task.cancel()
            except Exception:
                pass
            await asyncio.sleep(1)
            continue
    cprint("\n[FAIL] Gateway geht gerade nicht (3x Timeout)!", RED)
    cprint("Fix: 1) VPN/Proxy aus  2) Members-Intent im Portal AN  3) Token neu kopieren  4) In 1 Min retry", YELLOW)
    return None, None


async def main():
    bot = None
    bot_task = None
    while True:
        banner()
        cprint("NUR EIGENER SERVER / MIT ERLAUBNIS!", RED)
        if bot is None or bot.is_closed():
            # --- Schritt 1: Token ---
            print("\n [1] Token eingeben & checken")
            print(" [0] Beenden")
            saved = load_saved_token()
            if saved:
                cprint(f"\nGespeicherter Token: ****{saved[-4:]}", CYAN)
                print(" Tipp: '7' = gespeicherten Token nutzen / '8' = loeschen (neuer Bot)")
            w = (await ainput("\nWahl (1/0): ")).strip()
            if w == "0":
                return
            if w == "7" and saved:
                token = saved
            elif w == "8" and saved:
                try:
                    os.remove(TOKEN_FILE)
                    cprint("Gespeicherter Token geloescht.", GREEN)
                except OSError:
                    pass
                await asyncio.sleep(1)
                continue
            elif w == "1":
                print("\nDeveloper Portal -> Applications -> Bot -> Token (Reset Token -> Copy)")
                print("Intents aktivieren: SERVER MEMBERS + MESSAGE CONTENT\n")
                token = (await ainput("Token einfuegen: ")).strip().strip('"').strip("'")
                if len(token) < 20:
                    cprint("Token zu kurz!", RED)
                    await asyncio.sleep(1.5)
                    continue
            else:
                cprint("Druecke 1 fuer Token.", RED)
                await asyncio.sleep(1)
                continue

            bot, bot_task = await check_and_login(token)
            if bot is None:
                await ainput("\nEnter zum Zurueck...")
                continue
            # speichern?
            s = (await ainput("Token speichern? (j/n): ")).strip().lower()
            if s in ("j", "ja", "y"):
                try:
                    with open(TOKEN_FILE, "w", encoding="utf-8") as f:
                        f.write(token)
                    cprint("Gespeichert (token.txt).", GREEN)
                except OSError as e:
                    cprint(f"Speichern fehlgeschlagen: {e}", RED)
                await asyncio.sleep(1)

        # --- Schritt 2: Server ---
        banner()
        cprint(f"Eingeloggt als: {bot.user} [ONLINE]", GREEN)
        guild = await pick_guild(bot)
        if guild is None:
            # zurueck zum Start (eingeloggt bleiben)
            continue

        # --- Schritt 3: Nuke-Menue ---
        res = await nuke_menu(bot, guild)
        if res == "exit":
            if bot_task and not bot_task.done():
                try:
                    bot_task.cancel()
                except Exception:
                    pass
            return
        # bei "switch" -> wieder Serverwahl (bot bleibt online)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
    except Exception as e:
        cprint(f"\nFehler: {e}", RED)
    finally:
        try:
            input("\nEnter zum Beenden...")
        except EOFError:
            pass
