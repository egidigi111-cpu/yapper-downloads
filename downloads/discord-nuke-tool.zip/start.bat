@echo off
title Nuke Tool - Corona like
cd /d "%~dp0"
python nuke_tool.py
pause
