"""
MultiLarpNukeTools.py - Nuke-Terminal (fuer jeden nutzbar)
Ablauf:
  [1] Token eingeben -> wird gecheckt -> weiter zu Nuke-Menue
  Nuke-Menue:
  [1] Jeden Kicken / [2] Jeden Bannen / [3] Alle Kanaele loeschen (ausser 1)
  [4] Rollen loeschen / [5] FULL NUKE

Start fuer jeden:  python MultiLarpNukeTools.py
Braucht: Python 3.10+ und:  pip install discord.py colorama aiohttp
NUR EIGENER SERVER / MIT ERLAUBNIS! Sonst Discord-ToS-Verstoss.
Bot braucht Administrator + SERVER MEMBERS INTENT im Developer Portal.
"""

import asyncio
import os
import subprocess
import sys
import time


def ensure_deps():
    """Fehlende Pakete automatisch nachinstallieren (fuer jeden nutzbar)."""
    missing = []
    try:
        import discord  # noqa
    except ImportError:
        missing.append("discord.py")
    try:
        import colorama  # noqa
    except ImportError:
        missing.append("colorama")
    try:
        import aiohttp  # noqa
    except ImportError:
        missing.append("aiohttp")
    if missing:
        print("Installiere fehlende Pakete:", ", ".join(missing))
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "-U"] + missing)
        except Exception as e:
            print("Auto-Install fehlgeschlagen:", e)
            print("Manuell:  pip install discord.py colorama aiohttp")
            input("\nEnter zum Beenden...")
            sys.exit(1)


ensure_deps()

import aiohttp
import discord

try:
    from colorama import init as colorama_init, Fore, Style
    colorama_init()
    GREEN, RED, YELLOW, CYAN = Fore.GREEN, Fore.RED, Fore.YELLOW, Fore.CYAN
    RESET = Style.RESET_ALL
except ImportError:
    GREEN = RED = YELLOW = CYAN = RESET = ""

BASE = os.path.dirname(os.path.abspath(__file__))
TOKEN_FILE = os.path.join(BASE, "token.txt")


def cprint(t, c=""):
    print(f"{c}{t}{RESET}")


def banner():
    os.system("cls" if os.name == "nt" else "clear")
    try:
        os.system("title MultiLarpNukeTools")
    except Exception:
        pass
    print(r"""
  __  __ _   _ _  _______ _____ _      _    ____  ____
 |  \/  | | | | ||_   _|_   _| |    / \  |  _ \|  _ \
 | |\/| | | | | |  | |   | | | |   / _ \ | |_) | |_) |
 | |  | | |_| | |  | |   | | | |__/ ___ \|  _ <|  __/
 |_|  |_|\___/|_|  |_|   |_| |_____/_/   \_\_| \_\_|
        MultiLarpNukeTools - NUKE TERMINAL
""")


async def ainput(prompt=""):
    return await asyncio.to_thread(input, prompt)


class NukeBot(discord.Client):
    def __init__(self):
        # default + members = stabil + trotzdem schnell (kein presence-spam wie bei all)
        intents = discord.Intents.default()
        intents.members = True  # braucht SERVER MEMBERS INTENT im Portal
        intents.messages = True
        super().__init__(intents=intents, chunk_guilds_at_startup=True,
                         max_messages=None)
        self.ready_event = asyncio.Event()

    async def on_ready(self):
        self.ready_event.set()


def load_saved_token():
    if os.path.exists(TOKEN_FILE):
        try:
            with open(TOKEN_FILE, "r", encoding="utf-8") as f:
                t = f.read().strip()
                if len(t) > 20:
                    return t
        except OSError:
            pass
    return None


# ---------- Aktionen ----------

async def refresh_cache_if_empty(guild, bot):
    # Falls Cache leer (z.B. nach Reconnect): neu vom Gateway holen
    if not guild.members or not guild.channels:
        fresh = bot.get_guild(guild.id)
        if fresh and (len(fresh.members) > len(guild.members) or len(fresh.channels) > len(guild.channels)):
            return fresh
        try:
            await asyncio.wait_for(guild.chunk(), timeout=10)
        except Exception:
            pass
    # Fallback: Kanaele/Rollen per REST nachladen wenn Gateway-Cache leer
    if not guild.channels:
        try:
            fetched = await guild.fetch_channels()
            # fetch_channels gibt keine Cache-Fuellung, aber wir nutzen sie direkt nicht hier -
            # nur als Hinweis dass Rechte da sind
            cprint(f"REST: {len(fetched)} Kanaele gefunden.", CYAN)
        except Exception as e:
            cprint(f"Kann Kanaele nicht laden: {type(e).__name__} - Bot hat kein Admin?", RED)
    return guild


# ---------- Turbo-Config ----------
CONC_MEMBERS = 30   # parallel Kicks/Bans (Discord limitiert selbst, mehr = schneller bis zum Limit)
CONC_CH = 20        # parallel Kanal-/Rollen-Deletes
VERBOSE_EVERY = 25  # nur jede N-te Zeile printen (Terminal bremst sonst stark)


def progress(done, total, label):
    if done % VERBOSE_EVERY == 0 or done == total:
        print(f"  [{label}] {done}/{total}")


async def elevate_bot_role(guild, bot):
    """Versucht Bot-Rolle automatisch nach oben zu schieben (so weit Discord es erlaubt)."""
    try:
        me = guild.get_member(bot.user.id) or guild.me
        if me is None:
            return
        if not me.guild_permissions.manage_roles and not me.guild_permissions.administrator:
            cprint("AUTO-RANG: keine Manage-Roles Rechte - manuell nach oben ziehen!", YELLOW)
            return
        top = me.top_role
        # hoechste Position = Anzahl Rollen (ohne @everyone geht bis len-1)
        max_pos = max((r.position for r in guild.roles), default=1)
        if top.position >= max_pos:
            cprint(f"AUTO-RANG: Bot-Rolle schon oben ({top.name} Pos {top.position}).", GREEN)
            return
        cprint(f"AUTO-RANG: schiebe {top.name} von Pos {top.position} auf {max_pos}...", YELLOW)
        await top.edit(position=max_pos, reason="nuke auto-elevate")
        await asyncio.sleep(0.3)
        cprint(f"AUTO-RANG: jetzt Pos {me.top_role.position}.", GREEN)
    except discord.Forbidden:
        cprint("AUTO-RANG Forbidden: Rolle manuell nach oben ziehen!", RED)
    except Exception as e:
        cprint(f"AUTO-RANG Hinweis: {type(e).__name__}", YELLOW)


async def ban_all(guild, bot, also_bots=False):
    guild = await refresh_cache_if_empty(guild, bot)
    await elevate_bot_role(guild, bot)
    me_id = bot.user.id
    me_member = guild.get_member(me_id) or guild.me
    targets = [m for m in guild.members
               if m.id not in (me_id, guild.owner_id)
               and (me_member is None or m != me_member) and (also_bots or not m.bot)]
    if not targets:
        cprint(f"\nKeine Targets! Cache leer ({len(guild.members)} Member, total {guild.member_count}).", RED)
        cprint("Fix: Members-Intent AN? Bot neu einladen mit Admin? Kleinen Server testen.", YELLOW)
        return 0, 0
    cprint(f"\nBanne {len(targets)} Mitglieder (TURBO x{CONC_MEMBERS})...", YELLOW)
    ok = fail = 0
    sem = asyncio.Semaphore(CONC_MEMBERS)

    async def do(m):
        nonlocal ok, fail
        async with sem:
            try:
                await guild.ban(m, reason="nuke", delete_message_days=0)
                ok += 1
                progress(ok + fail, len(targets), "BAN")
            except discord.Forbidden:
                fail += 1
            except discord.HTTPException as e:
                if getattr(e, "status", 0) == 429:  # Rate-Limit: einmal warten + retry
                    await asyncio.sleep(getattr(e, "retry_after", 2))
                    try:
                        await guild.ban(m, reason="nuke", delete_message_days=0)
                        ok += 1
                        progress(ok + fail, len(targets), "BAN")
                        return
                    except Exception:
                        pass
                fail += 1
            except Exception:
                fail += 1

    await asyncio.gather(*(do(m) for m in targets))
    cprint(f"Fertig: {ok} gebannt, {fail} Fehler.", GREEN)


async def kick_all(guild, bot, also_bots=False):
    guild = await refresh_cache_if_empty(guild, bot)
    await elevate_bot_role(guild, bot)
    me_id = bot.user.id
    me_member = guild.get_member(me_id) or guild.me
    targets = [m for m in guild.members
               if m.id not in (me_id, guild.owner_id)
               and (me_member is None or m != me_member) and (also_bots or not m.bot)]
    if not targets:
        cprint(f"\nKeine Targets! Cache leer ({len(guild.members)} Member, total {guild.member_count}).", RED)
        cprint("Fix: Members-Intent AN? Bot neu einladen mit Admin?", YELLOW)
        return 0, 0
    cprint(f"\nKicke {len(targets)} Mitglieder (TURBO x{CONC_MEMBERS})...", YELLOW)
    ok = fail = 0
    sem = asyncio.Semaphore(CONC_MEMBERS)

    async def do(m):
        nonlocal ok, fail
        async with sem:
            try:
                await m.kick(reason="nuke")
                ok += 1
                progress(ok + fail, len(targets), "KICK")
            except discord.Forbidden:
                fail += 1
            except discord.HTTPException as e:
                if getattr(e, "status", 0) == 429:
                    await asyncio.sleep(getattr(e, "retry_after", 2))
                    try:
                        await m.kick(reason="nuke")
                        ok += 1
                        progress(ok + fail, len(targets), "KICK")
                        return
                    except Exception:
                        pass
                fail += 1
            except Exception:
                fail += 1

    await asyncio.gather(*(do(m) for m in targets))
    cprint(f"Fertig: {ok} gekickt, {fail} Fehler.", GREEN)


async def del_channels(guild, keep_one=True):
    guild = guild  # cached guild, nicht fetchen
    if not guild.channels:
        try:
            fetched = await guild.fetch_channels()
            cprint(f"Nutze {len(fetched)} REST-Kanaele (Cache war leer).", YELLOW)
            # fetched sind Channel-Objekte -> direkt loeschen
            ok = fail = 0
            keep_rest = None
            if keep_one:
                try:
                    keep_rest = await guild.create_text_channel("nuked")
                except Exception:
                    pass
            sem0 = asyncio.Semaphore(CONC_CH)

            async def del_rest(c):
                nonlocal ok, fail
                if keep_rest and c.id == keep_rest.id:
                    return
                async with sem0:
                    try:
                        await c.delete(reason="nuke")
                        ok += 1
                        progress(ok + fail, len(fetched), "DEL")
                    except Exception:
                        fail += 1

            await asyncio.gather(*(del_rest(c) for c in fetched))
            cprint(f"Fertig: {ok} geloescht, {fail} Fehler.", GREEN)
            return keep_rest
        except Exception as e:
            cprint(f"Kanal-Liste leer und REST fail: {type(e).__name__}", RED)
            return None
    keep = None
    if keep_one:
        try:
            keep = await guild.create_text_channel("nuked")
            cprint(f"Keep-Kanal erstellt: #{keep.name}", CYAN)
        except Exception:
            keep = guild.text_channels[0] if guild.text_channels else None
            if keep:
                cprint(f"Behalte: #{keep.name}", CYAN)
    doomed = [c for c in list(guild.channels) if keep is None or c.id != keep.id]
    # Kategorien zuletzt loeschen (sonst Fehler/Retry wenn Kinder noch drin sind)
    doomed.sort(key=lambda c: (str(c.type) == "category", c.position if hasattr(c, "position") else 0))
    cprint(f"\nLoesche {len(doomed)} Kanaele (TURBO x{CONC_CH}, 1 bleibt)...", YELLOW)
    ok = fail = 0
    sem = asyncio.Semaphore(CONC_CH)

    async def del_one(c):
        nonlocal ok, fail
        async with sem:
            try:
                await c.delete(reason="nuke")
                ok += 1
                progress(ok + fail, len(doomed), "DEL")
            except discord.Forbidden:
                fail += 1
            except discord.HTTPException as e:
                if getattr(e, "status", 0) == 429:
                    await asyncio.sleep(getattr(e, "retry_after", 2))
                    try:
                        await c.delete(reason="nuke")
                        ok += 1
                        progress(ok + fail, len(doomed), "DEL")
                        return
                    except Exception:
                        pass
                fail += 1
            except Exception:
                fail += 1

    await asyncio.gather(*(del_one(c) for c in doomed))
    if keep_one and keep is None:
        try:
            keep = await guild.create_text_channel("nuked")
        except Exception:
            pass
    cprint(f"Fertig: {ok} geloescht, {fail} Fehler.", GREEN)
    return keep


async def del_roles(guild, bot=None):
    me = guild.me
    if me is None and bot is not None:
        me = guild.get_member(bot.user.id)
    if me is None:
        cprint("WARNUNG: eigene Rolle unbekannt - versuche trotzdem (nur @everyone/managed skip).", YELLOW)
        targets = [r for r in guild.roles
                   if not r.is_default() and not r.managed
                   and not (r.tags and (r.tags.bot_id or r.tags.integration_id))]
    else:
        top = me.top_role
        targets = [r for r in guild.roles
                   if not r.is_default() and not r.managed and r < top
                   and not (r.tags and (r.tags.bot_id or r.tags.integration_id))]
    cprint(f"\nLoesche {len(targets)} Rollen (TURBO x{CONC_CH})...", YELLOW)
    ok = fail = 0
    sem = asyncio.Semaphore(CONC_CH)

    async def del_one(r):
        nonlocal ok, fail
        async with sem:
            try:
                await r.delete(reason="nuke")
                ok += 1
                progress(ok + fail, len(targets), "ROLLE")
            except discord.Forbidden:
                fail += 1
            except discord.HTTPException as e:
                if getattr(e, "status", 0) == 429:
                    await asyncio.sleep(getattr(e, "retry_after", 2))
                    try:
                        await r.delete(reason="nuke")
                        ok += 1
                        progress(ok + fail, len(targets), "ROLLE")
                        return
                    except Exception:
                        pass
                fail += 1
            except Exception:
                fail += 1

    await asyncio.gather(*(del_one(r) for r in targets))
    cprint(f"Fertig: {ok} geloescht, {fail} Fehler.", GREEN)


async def full_nuke(guild, bot):
    cprint(f"\n!!! FULL NUKE auf '{guild.name}' (TURBO: Rollen+Kanaele parallel) !!!", RED)
    # Rollen + Kanaele gleichzeitig statt nacheinander = ca. halbe Zeit
    _, keep = await asyncio.gather(del_roles(guild, bot), del_channels(guild, True))
    w = (await ainput("Auch Bots bannen? (j/n): ")).strip().lower()
    await ban_all(guild, bot, also_bots=w in ("j", "ja", "y"))
    if keep:
        try:
            await keep.send("Server genuked. 1 Kanal bleibt.")
        except Exception:
            pass
    cprint("FULL NUKE fertig.", GREEN)


# ---------- Menues ----------

async def pick_guild(bot):
    guilds = list(bot.guilds)
    if not guilds:
        cprint("\nBot ist auf KEINEM Server!", RED)
        cprint(f"Lade ihn ein:\nhttps://discord.com/oauth2/authorize?client_id={bot.user.id}&permissions=8&scope=bot", YELLOW)
        await ainput("\nEnter zum Zurueck...")
        return None
    print("\n--- Server waehlen ---")
    for i, g in enumerate(guilds, 1):
        print(f" [{i}] {g.name} (Member: {g.member_count})")
    print(" [0] Zurueck")
    while True:
        w = (await ainput("\nNummer: ")).strip()
        if w == "0":
            return None
        try:
            g = guilds[int(w) - 1]
            return g
        except (ValueError, IndexError):
            cprint("Ungueltig.", RED)


async def confirm(action, guild):
    w = (await ainput(f"WIRKLICH '{action}' auf '{guild.name}'? (ja/NEIN): ")).strip().lower()
    return w in ("ja", "y", "j", "yes")


async def ensure_members(guild):
    """Member-Cache fuellen - cached Guild nutzen, nie fetch_guild ueberschreiben."""
    try:
        total = guild.member_count or 0
        cprint(f"Cache: {len(guild.members)}/{total} Member, {len(guild.channels)} Kanaele, {len(guild.roles)} Rollen", CYAN)
        if len(guild.members) >= max(total - 2, 0):
            return
        if total >= 10:
            cprint(f"Lade {total} Member (max 15s)...", YELLOW)
            try:
                await asyncio.wait_for(guild.chunk(), timeout=15)
            except asyncio.TimeoutError:
                pass
            cprint(f"Nach Load: {len(guild.members)}/{total} im Cache", GREEN)
        if not guild.members and total > 1:
            cprint("WARNUNG: Member-Liste leer! Members-Intent im Portal AN? Bot hat Rechte?", RED)
    except Exception as e:
        cprint(f"Member-Load Hinweis: {type(e).__name__}", YELLOW)


async def check_perms(guild, bot):
    me = guild.get_member(bot.user.id) or guild.me
    if me is None:
        cprint("PERMS: eigenes Member nicht im Cache - Reconnect abwarten!", RED)
        return False
    p = me.guild_permissions
    cprint(f"PERMS: admin={p.administrator} ban={p.ban_members} kick={p.kick_members} channels={p.manage_channels} roles={p.manage_roles} | Top-Rolle: {me.top_role} (Pos {me.top_role.position})", CYAN)
    # Rollen-Hierarchie zeigen
    top = me.top_role
    higher_roles = [r for r in guild.roles if r.position >= top.position and not r.is_default() and r != top]
    higher_users = [m for m in guild.members if m.top_role.position >= top.position and m.id != me.id and m.id != guild.owner_id]
    if not p.administrator:
        cprint("FEHLT: Administrator! Neu einladen mit:", RED)
        cprint(f"https://discord.com/oauth2/authorize?client_id={bot.user.id}&permissions=8&scope=bot", YELLOW)
        return False
    if higher_roles:
        cprint(f"HINWEIS: {len(higher_roles)} Rollen >= Bot-Rolle werden uebersprungen (Bot-Rolle nach GANZ OBEN ziehen!).", YELLOW)
    if higher_users:
        cprint(f"HINWEIS: {len(higher_users)} User haben hoehere/gleiche Rolle und geben Forbidden.", YELLOW)
    return True


async def nuke_menu(bot, guild):
    # WICHTIG: cached Guild vom Gateway nutzen, KEIN fetch_guild (das leert den Cache!)
    cached = bot.get_guild(guild.id) or guild
    guild = cached
    await ensure_members(guild)
    me = guild.get_member(bot.user.id) or guild.me
    if me:
        await check_perms(guild, bot)
        cprint("Wenn ueberall Forbidden: Bot-Rolle nach OBEN + Kick/Ban-Rechte geben!", YELLOW)
    else:
        cprint("Bot-Member nicht gefunden - warte 5s und oeffne Menue neu (6=Server wechseln).", RED)
    await ainput("\nEnter fuer Menue...")
    while True:
        banner()
        cprint(f"Bot: {bot.user}  |  Server: {guild.name} (Member: {getattr(guild, 'member_count', '?')})", GREEN)
        cprint("Bot, Owner + hoehere Rollen werden uebersprungen.", CYAN)
        print("\n [1] Jeden Kicken")
        print(" [2] Jeden Bannen")
        print(" [3] Alle Kanaele loeschen (ausser 1)")
        print(" [4] Alle Rollen loeschen")
        print(" [5] FULL NUKE")
        print(" [6] Server wechseln")
        print(" [0] Beenden")
        w = (await ainput("\nWahl: ")).strip()
        if w == "0":
            await bot.close()
            return "exit"
        if w == "6":
            return "switch"
        if w == "1":
            b = (await ainput("Auch Bots kicken? (j/n): ")).strip().lower() in ("j", "ja", "y")
            if await confirm("ALLE KICKEN", guild):
                await kick_all(guild, bot, b)
            await ainput("\nEnter...")
        elif w == "2":
            b = (await ainput("Auch Bots bannen? (j/n): ")).strip().lower() in ("j", "ja", "y")
            if await confirm("ALLE BANNEN", guild):
                await ban_all(guild, bot, b)
            await ainput("\nEnter...")
        elif w == "3":
            if await confirm("ALLE KANAELE LOESCHEN (ausser 1)", guild):
                await del_channels(guild, True)
            await ainput("\nEnter...")
        elif w == "4":
            if await confirm("ALLE ROLLEN LOESCHEN", guild):
                await del_roles(guild, bot)
            await ainput("\nEnter...")
        elif w == "5":
            if await confirm("FULL NUKE", guild):
                await full_nuke(guild, bot)
            await ainput("\nEnter...")
        else:
            cprint("Ungueltig.", RED)
            await asyncio.sleep(1)


async def check_and_login(token):
    """Token checken: erst schneller REST-Check (~1s), dann Gateway-Login."""
    cprint("\n[CHECK] Token wird geprueft...", YELLOW)
    t0 = time.monotonic()
    # Phase 1: schneller HTTP-Check, kein 30s Gateway-Wait bei falschem Token
    try:
        timeout = aiohttp.ClientTimeout(total=8)
        async with aiohttp.ClientSession(timeout=timeout) as s:
            async with s.get("https://discord.com/api/v10/users/@me",
                             headers={"Authorization": f"Bot {token}"}) as r:
                if r.status == 401:
                    cprint(f"\n[FAIL] Token ungueltig! ({time.monotonic()-t0:.1f}s)", RED)
                    return None, None
                if r.status == 429:
                    cprint("\n[FAIL] Rate-Limit, warte kurz und retry...", RED)
                    return None, None
                if r.status != 200:
                    cprint(f"\n[FAIL] Discord meldet Fehler {r.status} ({time.monotonic()-t0:.1f}s)", RED)
                    return None, None
                data = await r.json()
                cprint(f"[REST-OK] Bot gefunden: {data.get('username')} ({time.monotonic()-t0:.1f}s) - verbinde Gateway...", GREEN)
    except asyncio.TimeoutError:
        cprint("\n[FAIL] Keine Verbindung zu Discord (Timeout).", RED)
        return None, None
    except Exception as e:
        cprint(f"\n[WARN] REST-Check fehlgeschlagen ({type(e).__name__}), versuche Gateway...", YELLOW)

    # Phase 2: Gateway-Login mit 3 Versuchen a max 8s (statt 1x 12s)
    for versuch in (1, 2, 3):
        bot = NukeBot()
        task = asyncio.create_task(bot.start(token))
        try:
            cprint(f"[Gateway] Versuch {versuch}/3...", YELLOW)
            await asyncio.wait_for(bot.ready_event.wait(), timeout=8)
            cprint(f"\n[OK] Token gueltig! Eingeloggt als: {bot.user} ({time.monotonic()-t0:.1f}s)", GREEN)
            cprint(f"Invite (Admin): https://discord.com/oauth2/authorize?client_id={bot.user.id}&permissions=8&scope=bot", CYAN)
            return bot, task
        except asyncio.TimeoutError:
            cprint(f"[Gateway] Versuch {versuch} Timeout - retry...", YELLOW)
            try:
                await bot.close()
            except Exception:
                pass
            try:
                task.cancel()
            except Exception:
                pass
            await asyncio.sleep(1)
            continue
        except discord.LoginFailure:
            cprint("\n[FAIL] Token ungueltig (LoginFailure)!", RED)
            try:
                await bot.close()
            except Exception:
                pass
            return None, None
        except Exception as e:
            cprint(f"[Gateway] Fehler {type(e).__name__} - retry...", YELLOW)
            try:
                await bot.close()
            except Exception:
                pass
            try:
                task.cancel()
            except Exception:
                pass
            await asyncio.sleep(1)
            continue
    cprint("\n[FAIL] Gateway geht gerade nicht (3x Timeout)!", RED)
    cprint("Fix: 1) VPN/Proxy aus  2) Members-Intent im Portal AN  3) Token neu kopieren  4) In 1 Min retry", YELLOW)
    return None, None


async def main():
    bot = None
    bot_task = None
    while True:
        banner()
        cprint("NUR EIGENER SERVER / MIT ERLAUBNIS!", RED)
        if bot is None or bot.is_closed():
            # --- Schritt 1: Token ---
            print("\n [1] Token eingeben & checken")
            print(" [0] Beenden")
            saved = load_saved_token()
            if saved:
                cprint(f"\nGespeicherter Token: ****{saved[-4:]}", CYAN)
                print(" Tipp: '7' = gespeicherten Token nutzen / '8' = loeschen (neuer Bot)")
            w = (await ainput("\nWahl (1/0): ")).strip()
            if w == "0":
                return
            if w == "7" and saved:
                token = saved
            elif w == "8" and saved:
                try:
                    os.remove(TOKEN_FILE)
                    cprint("Gespeicherter Token geloescht.", GREEN)
                except OSError:
                    pass
                await asyncio.sleep(1)
                continue
            elif w == "1":
                print("\nDeveloper Portal -> Applications -> Bot -> Token (Reset Token -> Copy)")
                print("Intents aktivieren: SERVER MEMBERS + MESSAGE CONTENT\n")
                token = (await ainput("Token einfuegen: ")).strip().strip('"').strip("'")
                if len(token) < 20:
                    cprint("Token zu kurz!", RED)
                    await asyncio.sleep(1.5)
                    continue
            else:
                cprint("Druecke 1 fuer Token.", RED)
                await asyncio.sleep(1)
                continue

            bot, bot_task = await check_and_login(token)
            if bot is None:
                await ainput("\nEnter zum Zurueck...")
                continue
            # speichern?
            s = (await ainput("Token speichern? (j/n): ")).strip().lower()
            if s in ("j", "ja", "y"):
                try:
                    with open(TOKEN_FILE, "w", encoding="utf-8") as f:
                        f.write(token)
                    cprint("Gespeichert (token.txt).", GREEN)
                except OSError as e:
                    cprint(f"Speichern fehlgeschlagen: {e}", RED)
                await asyncio.sleep(1)

        # --- Schritt 2: Server ---
        banner()
        cprint(f"Eingeloggt als: {bot.user} [ONLINE]", GREEN)
        guild = await pick_guild(bot)
        if guild is None:
            # zurueck zum Start (eingeloggt bleiben)
            continue

        # --- Schritt 3: Nuke-Menue ---
        res = await nuke_menu(bot, guild)
        if res == "exit":
            if bot_task and not bot_task.done():
                try:
                    bot_task.cancel()
                except Exception:
                    pass
            return
        # bei "switch" -> wieder Serverwahl (bot bleibt online)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        pass
    except Exception as e:
        cprint(f"\nFehler: {e}", RED)
    finally:
        try:
            input("\nEnter zum Beenden...")
        except EOFError:
            pass
